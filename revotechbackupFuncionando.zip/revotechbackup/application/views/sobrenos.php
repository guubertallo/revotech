<?php $this->load->view('header'); ?>


<section class="section section-intro context-dark">
        <div class="intro-bg" style="background:url('<?php echo base_url('assets/images/bg-1-1700x803.jpg') ?>') no-repeat center center; background-size:cover;"></div>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-xl-8 text-center">
              <h1 class="font-weight-bold wow fadeInLeft">Sobre Nós</h1>
              
            </div>
          </div>
        </div>
      </section>
      <!-- About page about section-->
      <section class="section section-md">
        <div class="container">
          <div class="row row-40 justify-content-center">
            <div class="col-lg-6 col-12">
              <div class="offset-top-45 offset-lg-right-45">
                <div class="section-name wow fadeInRight" data-wow-delay=".2s">Sobre Nós</div>
                <h3 class="wow fadeInLeft text-capitalize" data-wow-delay=".3s">O que<span class="text-primary"> Fazemos</span></h3>
                
                <p class="wow fadeInUp" data-wow-delay=".4s">Nossas soluções tem como foco principal atender micro, pequenos e médios estabelecimentos comerciais em suas principais necessidades, como: adequação a Legislação Fiscal, automação das rotinas diárias e apoio na gestão do negócio. 
Hoje a REVOTECH está localizada na Califórnia Brasileira Ribeirão Preto-SP, como uma das maiores prestadoras de Serviços e Integradora de Soluções em Tecnologia da Informação para todos os níveis de mercado , desde o pequeno cliente até empresas de grande porte.
Atendemos em 26 Estados do Brasil + Distrito Federal, onde auxiliamos nossos clientes com as principais tecnologias fiscais do mercado: SAT, NFC-e, NF-e.</p>
                
                <div class="offset-top-20">
               


 <section class="section section bg-accent text-center">
        <div class="container">
          <div class="row row-30">
            <div class="col-6 col-md-4">
              <!--Box counter-->
              <article class="box-counter">
                <div class="box-counter-main"><span>547</span></div>
                <div class="box-counter-divider"></div>
                <p class="box-counter-title">Clientes Atendidos</p>
              </article>
            </div>
            <div class="col-6 col-md-4">
              <!--Box counter-->
              <article class="box-counter">
                <div class="box-counter-main">
                  <div class="counter">5</div>
                </div>
                <div class="box-counter-divider"></div>
                <p class="box-counter-title">Anos de Experiência</p>
              </article>
            </div>
            <div class="col-6 col-md-4">
              <!--Box counter-->
              <article class="box-counter">
                <div class="box-counter-main">
                  <div class="counter">99</div><span class="small">%</span>
                </div>
                <div class="box-counter-divider"></div>
                <p class="box-counter-title">Clientes Satisfeitos</p>
              </article>
            </div>
            
          </div>
        </div>
      </section>
     


                  
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-sm-10 col-12">
              <div class="block-decorate-img wow fadeInLeft" data-wow-delay=".2s"><img src="<?php echo base_url('assets/images/home-1-570x703.jpg') ?>" alt="" width="570" height="351"/>
              </div>
            </div>
          </div>
        </div>
      </section>
     
      
     
 
<?php $this->load->view('footer'); ?>