<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <title><?php echo $titulo; ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="<?php echo base_url('assets/images/favicon.ico') ?>" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Montserrat:300,400,700%7CPoppins:300,400,500,700,900">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css') ?>">
    <style>.ie-panel{display: none;background: #000000;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    
    <div class="preloader">
      <div class="preloader-body">
        <div class="cssload-container">
          <div class="cssload-speeding-wheel"></div>
        </div>
        <p>Carregando...</p>
      </div>
    </div>
    <div class="page">
      <header class="section page-header">
        <!--RD Navbar-->
        <div class="rd-navbar-wrap">
          <nav class="rd-navbar rd-navbar-classic" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed" data-md-device-layout="rd-navbar-fixed" data-lg-layout="rd-navbar-static" data-lg-device-layout="rd-navbar-static" data-xl-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-lg-stick-up-offset="46px" data-xl-stick-up-offset="46px" data-xxl-stick-up-offset="46px" data-lg-stick-up="true" data-xl-stick-up="true" data-xxl-stick-up="true">
            <div class="rd-navbar-collapse-toggle rd-navbar-fixed-element-1" data-rd-navbar-toggle=".rd-navbar-collapse"><span></span></div>
            <div class="rd-navbar-aside-outer rd-navbar-collapse bg-gray-dark">
              <div class="rd-navbar-aside">
                <ul class="list-inline navbar-contact-list">
                  <li>
                    <div class="unit unit-spacing-xs align-items-center">
                      <div class="unit-left"><span class="icon text-middle fa-phone"></span></div>
                      <div class="unit-body"><a href="tel:#">(16) 98163-9782</a></div>
                    </div>
                  </li>
                  <li>
                    <div class="unit unit-spacing-xs align-items-center">
                      <div class="unit-left"><span class="icon text-middle fa-envelope"></span></div>
                      <div class="unit-body"><a href="mailto:#">contato@revotechsolucoes.com.br</a></div>
                    </div>
                  </li>
                  <li>
                    <div class="unit unit-spacing-xs align-items-center">
                      <div class="unit-left"><span class="icon text-middle fa-map-marker"></span></div>
                      <div class="unit-body"><a href="#">Rua Nove , 45 - Portal dos Ipes - Ribeirão Preto - SP</a></div>
                    </div>
                  </li>
                </ul>
                <ul class="social-links">
                                    <li><a class="icon icon-sm icon-circle icon-circle-md icon-bg-white fa-cogs" href="#">&nbsp; Painel </a></li>
                </ul>
              </div>
            </div>
            <div class="rd-navbar-main-outer">
              <div class="rd-navbar-main">
                <!--RD Navbar Panel-->
                <div class="rd-navbar-panel">
                  <!--RD Navbar Toggle-->
                  <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                  <!--RD Navbar Brand-->
                  <div class="rd-navbar-brand">
                    <!--Brand--><a class="brand" href="<?php echo base_url() ?>"><img class="brand-logo-dark" src="<?php echo base_url('assets/images/logo-default-200x34.png') ?>" alt="" width="200" height="34"/><img class="brand-logo-light" src="<?php echo base_url('assets/images/logo-inverse-200x34.png') ?>" alt="" width="200" height="34"/></a>
                  </div>
                </div>
                <div class="rd-navbar-main-element">
           <div class="rd-navbar-nav-wrap">
                    <ul class="rd-navbar-nav">
                      <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo base_url() ?>">Home</a>
                      </li>
                      <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo base_url('sobrenos') ?>">Sobre Nós</a>
                      </li>
                      <li class="rd-nav-item"><a class="rd-nav-link" href="#">Soluções</a>
                        <ul class="rd-menu rd-navbar-megamenu">
                          <li class="rd-megamenu-item">
                            <h6 class="rd-megamenu-title">Sistemas</h6>
                            <ul class="rd-megamenu-list">
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('linkpro') ?>">Link Pro</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('navivendas') ?>">Navi Vendas</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('navivendas') ?>">XD Rest</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('navivendas') ?>">XD Pos</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('navivendas') ?>">XD Spa</a></li>

                             
                             
                            </ul>
                          </li>
                           <li class="rd-megamenu-item">
                            <h6 class="rd-megamenu-title">Soluções</h6>
                            <ul class="rd-megamenu-list">
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('linkpro') ?>">Revo Cloud</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('navivendas') ?>">Revo Ponto</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('navivendas') ?>">Vitrine Digital</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('navivendas') ?>">Cardapio Digital</a></li>
                             
                             
                            </ul>
                          </li>
                          <li class="rd-megamenu-item">
                            <h6 class="rd-megamenu-title">Serviços</h6>
                            <ul class="rd-megamenu-list">
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('manutencaocomp') ?>">Manutenção em Computadores</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('montagemcomp') ?>">Montagem de Computadores</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('suporteinfo') ?>">Suporte em Informatica</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="search-results.html">Contrato de Manutenção de Computadores</a></li>
                              



                            </ul>
                          </li>
                           
                        </ul>
                      </li>
                         <li class="rd-nav-item"><a class="rd-nav-link" href="#">Equipamentos</a>
                        <ul class="rd-menu rd-navbar-megamenu">
                          <li class="rd-megamenu-item">
                            <h6 class="rd-megamenu-title">Automação Comercial</h6>
                            <ul class="rd-megamenu-list">
                             <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('satfiscal') ?>">SAT Fiscal</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('impnaofiscal') ?>">Impressora Não Fiscal</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('impetiqueta') ?>">Impressora de Etiqueta</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('leitorcodbarras') ?>">Leitor de Cod. de Barras</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('pdv') ?>">PDV</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('gavetas') ?>">Gaveta de Dinheiro</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('terminaisconsulta') ?>">Terminal de Consulta</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('nobreaks') ?>">NoBreaks</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('pinpads') ?>">PinPads</a></li>
                                       
                             
                            </ul>
                          </li>
                          <li class="rd-megamenu-item">
                            <h6 class="rd-megamenu-title">Hardwares</h6>
                            <ul class="rd-megamenu-list">
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('notebooks') ?>">Notebooks</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('desktops') ?>">Desktops</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('monitores') ?>">Monitores</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('tablets') ?>">Tablets</a></li>
                 



                            </ul>
                            <li class="rd-megamenu-item">
                            <h6 class="rd-megamenu-title">Perifericos</h6>
                            <ul class="rd-megamenu-list">
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="grid-system.html">WebCam</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('mouses') ?>">Mouse</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('teclados') ?>">Teclado</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('fonesdeouvido') ?>">Fone de Ouvido</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('cabos') ?>">Cabos</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('adaptadores') ?>">Adaptadores</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('caixasdesom') ?>">Caixas de Som</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="search-results.html">Roteadores</a></li>



                            </ul>
                            <li class="rd-megamenu-item">
                            <h6 class="rd-megamenu-title">Suprimentos</h6>
                            <ul class="rd-megamenu-list">
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('bobinas') ?>">Bobina Termica </a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('ribbons') ?>">Ribbon</a></li>
                              <li class="rd-megamenu-list-item"><a class="rd-megamenu-list-link" href="<?php echo base_url('etiquetas') ?>">Etiqueta Gondola</a></li>
                                               



                            </ul>
                          </li>
                           
                        </ul>
                      </li>
                      <li class="rd-nav-item"><a class="rd-nav-link" href="#">Ajuda</a>
                        <ul class="rd-menu rd-navbar-dropdown">
                          <li class="rd-dropdown-item"><a class="rd-dropdown-link" href="<?php echo base_url('treinamentos') ?>">2º Via Boleto</a>
                          </li>
                          <li class="rd-dropdown-item"><a class="rd-dropdown-link" href="<?php echo base_url('treinamentos') ?>">Treinamentos</a>
                          </li>
                          <li class="rd-dropdown-item"><a class="rd-dropdown-link" href="<?php echo base_url('downloads') ?>">Downloads</a>
                          </li>
                          <li class="rd-dropdown-item"><a class="rd-dropdown-link" href="<?php echo base_url('blog') ?>">Blog</a>
                          </li>
                        </ul>
                      </li>
                   
                      
                      <li class="rd-nav-item"><a class="rd-nav-link" href="<?php echo base_url('contato') ?>">Contato</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </nav>
        </div>
      </header>