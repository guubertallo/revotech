<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pagina extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('url');
}


	public function index()
	{
		$dados['titulo'] = 'Revotech - Soluções em Automação Comercial';
		$this->load->view('home' , $dados);
	}

	public function sobrenos()
	{
		$dados['titulo'] = 'Sobre Nós - Revotech - Soluções em Automação Comercial';
		$this->load->view('sobrenos' , $dados);
	}


/* SISTEMAS */

	public function linkpro()
	{
		$dados['titulo'] = 'Link pro - Revotech - Soluções em Automação Comercial';
		$this->load->view('linkpro' , $dados);
	}

    public function revovendas()
	{
		$dados['titulo'] = 'Revo Vendas - Revotech - Soluções em Automação Comercial';
		$this->load->view('revovendas' , $dados);
	}

	public function xdpos()
	{
		$dados['titulo'] = 'XD POS - Revotech - Soluções em Automação Comercial';
		$this->load->view('xdpos' , $dados);
	}

	public function xdrest()
	{
		$dados['titulo'] = 'XD REST - Revotech - Soluções em Automação Comercial';
		$this->load->view('xdrest' , $dados);
	}

	public function xdspa()
	{
		$dados['titulo'] = 'XD SPA - Revotech - Soluções em Automação Comercial';
		$this->load->view('xdspa' , $dados);
	}



/* SOLUCOES */

public function revocloud()
	{
		$dados['titulo'] = 'Revo Cloud - Revotech - Soluções em Automação Comercial';
		$this->load->view('revocloud' , $dados);
	}

    public function revoponto()
	{
		$dados['titulo'] = 'Revo Ponto - Revotech - Soluções em Automação Comercial';
		$this->load->view('revoponto' , $dados);
	}

	public function cardapiodigital()
	{
		$dados['titulo'] = 'Cardapio Digital - Revotech - Soluções em Automação Comercial';
		$this->load->view('cardapiodigital' , $dados);
	}

	public function vitrinedigital()
	{
		$dados['titulo'] = 'Vitrine Digital - Revotech - Soluções em Automação Comercial';
		$this->load->view('vitrinedigital' , $dados);
	}


/* SERVIÇOS */

public function manutencaocomp()
	{
		$dados['titulo'] = 'Manutencao Computadores - Revotech - Soluções em Automação Comercial';
		$this->load->view('manutencaocomp' , $dados);
	}

    public function montagemcomp()
	{
		$dados['titulo'] = 'Montagem Computadores - Revotech - Soluções em Automação Comercial';
		$this->load->view('montagemcomp' , $dados);
	}

	public function suporteinfo()
	{
		$dados['titulo'] = 'Suporte Informatica - Revotech - Soluções em Automação Comercial';
		$this->load->view('suporteinfo' , $dados);
	}

	public function contratomanutencomp()
	{
		$dados['titulo'] = 'Contrato Manutenção - Revotech - Soluções em Automação Comercial';
		$this->load->view('contratomanutencomp' , $dados);
	}


/* AUTOMACAO COMERCIAL */

    public function satfiscal()
	{
		$dados['titulo'] = 'SAT FISCAL - Revotech - Soluções em Automação Comercial';
		$this->load->view('satfiscal' , $dados);
	}

    public function impnaofiscal()
	{
		$dados['titulo'] = 'Impressoras Nao Fiscais - Revotech - Soluções em Automação Comercial';
		$this->load->view('impnaofiscal' , $dados);
	}

	public function impetiqueta()
	{
		$dados['titulo'] = 'Impressoras de Etiqueta - Revotech - Soluções em Automação Comercial';
		$this->load->view('impetiqueta' , $dados);
	}

	public function leitorcodbarras()
	{
		$dados['titulo'] = 'Leitor Codigo de Barras - Revotech - Soluções em Automação Comercial';
		$this->load->view('leitorcodbarras' , $dados);
	}

	public function pdvs()
	{
		$dados['titulo'] = 'PDVs - Revotech - Soluções em Automação Comercial';
		$this->load->view('pdvs' , $dados);
	}

    public function gavetas()
	{
		$dados['titulo'] = 'Gavetas - Revotech - Soluções em Automação Comercial';
		$this->load->view('gavetas' , $dados);
	}

	public function terminaisconsulta()
	{
		$dados['titulo'] = 'Terminais Consulta - Revotech - Soluções em Automação Comercial';
		$this->load->view('terminaisconsulta' , $dados);
	}

	public function nobreaks()
	{
		$dados['titulo'] = 'No Breaks - Revotech - Soluções em Automação Comercial';
		$this->load->view('nobreaks' , $dados);
	}

    public function pinpads()
	{
		$dados['titulo'] = 'PinPads - Revotech - Soluções em Automação Comercial';
		$this->load->view('pinpads' , $dados);
	}


/* HARDWARES */

  public function notebooks()
	{
		$dados['titulo'] = 'Notebooks - Revotech - Soluções em Automação Comercial';
		$this->load->view('notebooks' , $dados);
	}

    public function desktops()
	{
		$dados['titulo'] = 'Desktops - Revotech - Soluções em Automação Comercial';
		$this->load->view('desktops' , $dados);
	}

	public function monitores()
	{
		$dados['titulo'] = 'Monitores - Revotech - Soluções em Automação Comercial';
		$this->load->view('monitores' , $dados);
	}

	public function tablets()
	{
		$dados['titulo'] = 'Tablets - Revotech - Soluções em Automação Comercial';
		$this->load->view('tablets' , $dados);
	}





/* PERIFERICOS */

    public function webcams()
	{
		$dados['titulo'] = 'WebCams - Revotech - Soluções em Automação Comercial';
		$this->load->view('webcams' , $dados);
	}

    public function mouses()
	{
		$dados['titulo'] = 'Mouses - Revotech - Soluções em Automação Comercial';
		$this->load->view('mouses' , $dados);
	}

	public function teclados()
	{
		$dados['titulo'] = 'Teclados - Revotech - Soluções em Automação Comercial';
		$this->load->view('teclados' , $dados);
	}

	public function fonesdeouvido()
	{
		$dados['titulo'] = 'Fones de Ouvido - Revotech - Soluções em Automação Comercial';
		$this->load->view('fonesdeouvido' , $dados);
	}

	public function cabos()
	{
		$dados['titulo'] = 'Cabos - Revotech - Soluções em Automação Comercial';
		$this->load->view('cabos' , $dados);
	}

    public function adaptadores()
	{
		$dados['titulo'] = 'Adaptadores - Revotech - Soluções em Automação Comercial';
		$this->load->view('adaptadores' , $dados);
	}

	public function caixasdesom()
	{
		$dados['titulo'] = 'Caixas de Som - Revotech - Soluções em Automação Comercial';
		$this->load->view('caixasdesom' , $dados);
	}

	public function roteadores()
	{
		$dados['titulo'] = 'Roteadores - Revotech - Soluções em Automação Comercial';
		$this->load->view('roteadores' , $dados);
	}


/* SUPRIMENTOS */

    public function bobinas()
	{
		$dados['titulo'] = 'Bobinas - Revotech - Soluções em Automação Comercial';
		$this->load->view('bobinas' , $dados);
	}

	public function ribbons()
	{
		$dados['titulo'] = 'Ribbons - Revotech - Soluções em Automação Comercial';
		$this->load->view('ribbons' , $dados);
	}

	public function etiquetas()
	{
		$dados['titulo'] = 'Etiquetas - Revotech - Soluções em Automação Comercial';
		$this->load->view('etiquetas' , $dados);
	}



/* AJUDA */

public function viaboleto()
	{
		$dados['titulo'] = '2 Via Boleto - Revotech - Soluções em Automação Comercial';
		$this->load->view('viaboleto' , $dados);
	}

	public function treinamentos()
	{
		$dados['titulo'] = 'Treinamentos - Revotech - Soluções em Automação Comercial';
		$this->load->view('treinamentos' , $dados);
	}

	public function downloads()
	{
		$dados['titulo'] = 'Downloads - Revotech - Soluções em Automação Comercial';
		$this->load->view('downloads' , $dados);
	}

	public function blog()
	{
		$dados['titulo'] = 'Blog - Revotech - Soluções em Automação Comercial';
		$this->load->view('blog' , $dados);
	}





public function contato()
	{
		$dados['titulo'] = 'Contato - Revotech - Soluções em Automação Comercial';
		$this->load->view('contato' , $dados);
	}

	public function painel()
	{
		$dados['titulo'] = 'Painel - Revotech - Soluções em Automação Comercial';
		$this->load->view('painel/login' , $dados);
	}

}
