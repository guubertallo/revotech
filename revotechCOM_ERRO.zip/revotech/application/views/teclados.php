<?php $this->load->view('header'); ?>


<section class="section section-intro context-dark">
        <div class="intro-bg" style="background:url('<?php echo base_url('assets/images/bg-1-1700x803.jpg') ?>') no-repeat center center; background-size:cover;"></div>
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-xl-8 text-center">
              <h1 class="font-weight-bold wow fadeInLeft">Teclados</h1>
              
            </div>
          </div>
        </div>
      </section>

      <br>
      <br>
      <br>
      <center>

      PAGINA EM CONSTRUÇAO

</center>
      <br>
      <br>
      <br>

     
      
     
 
<?php $this->load->view('footer'); ?>