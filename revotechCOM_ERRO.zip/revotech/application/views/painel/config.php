<?php $this->load->view('painel/header'); ?>
<br>
<center>
					<?php
	if($msg = get_msg()):
		echo '<div class="msg-box">'.$msg.'</div>';
	endif;
?>
<br>


				</div>





				<form action="https://revotechsolucoes.com.br/index.php/setup/alterar" method="post" class="login100-form validate-form">
					<span class="login100-form-title">
						<?php echo $h2; ?>
					</span>


					<div class="wrap-input100 validate-input" data-validate = "Usuario requerido">
						<?php echo form_input('login',set_value('login'),array('class'=>'input100')); ?>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="fa-user-md" aria-hidden="true"></span>
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Usuario requerido">
						<?php echo form_input('email',set_value('email'),array('class'=>'input100')); ?>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="fa fa-envelope" aria-hidden="true"></span>
						</span>
					</div>

					
					<div class="wrap-input100 validate-input" data-validate = "Password requerida">
						<?php echo form_password('senha','',array('class'=>'input100')); ?>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="fa fa-lock" aria-hidden="true"></span>
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Password requerida">
						<?php echo form_password('senha2','',array('class'=>'input100')); ?>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="fa fa-lock" aria-hidden="true"></span>
						</span>
					</div>


				
					
					<div class="container-login100-form-btn">
						<button  name="enviar" class="login100-form-btn">
							Salvar Dados
						</button>
					</div>

					<br><br>
					
					
				</form>



			
			</center>
<?php $this->load->view('painel/footer'); ?>
<br>
<br>