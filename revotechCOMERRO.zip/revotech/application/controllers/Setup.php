<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setup extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->model('option_model', 'option');

}

public function index(){
	if($this->option->get_option('setup_executado') == 1):
		redirect('setup/alterar','refresh');
	else:
		redirect('setup/instalar','refresh');
	endif;
}

public function instalar(){
if($this->option->get_option('setup_executado') == 1):
		redirect('setup/alterar','refresh');
	endif;

$this->form_validation->set_rules('login','login', 'trim|required|min_length[5]');
$this->form_validation->set_rules('email','E-Mail', 'trim|required|valid_email');
$this->form_validation->set_rules('senha','Senha', 'trim|required|min_length[6]');
$this->form_validation->set_rules('senha2','Repita a Senha', 'trim|required|min_length[6]|matches[senha]');

if($this->form_validation->run() == FALSE):
	if(validation_errors()):
		set_msg(validation_errors());
	endif;
else:

$dados_form = $this->input->post();
	$this->option->update_option('user_login', $dados_form['login']);
	$this->option->update_option('user_email', $dados_form['email']);
	$this->option->update_option('user_pass', password_hash( $dados_form['senha'], PASSWORD_DEFAULT));
	$inserido = $this->option->update_option('setup_executado', 1);
if($inserido):
			set_msg('<p>Sistema Instalado</p>');
			redirect('setup/login', 'refresh');
	endif;	
endif;

$dados['titulo'] = 'Setup do Sistema - Revotech';
$dados['h2'] = 'Setup do Sistema';
$this->load->view('painel/setup', $dados);

	}


public function login(){
if($this->option->get_option('setup_executado') != 1):
		redirect('setup/instalar','refresh');
	endif;

$this->form_validation->set_rules('login','Login', 'trim|required|min_length[5]');
$this->form_validation->set_rules('senha','Senha', 'trim|required|min_length[6]');

if($this->form_validation->run() == FALSE):
	if(validation_errors()):
		set_msg(validation_errors());
	endif;
else:

$dados_form = $this->input->post();
if($this->option->get_option('user_login') == $dados_form['login']):
	if(password_verify($dados_form['senha'], $this->option->get_option('user_pass') )):
$this->session->set_userdata('logged', TRUE);
$this->session->set_userdata('user_login', $dados_form['login']);
$this->session->set_userdata('user_email', $this->option->get_option('user_email'));
redirect('setup/alterar','refresh');

	else: 
		set_msg('<p>Senha Incorreta</p>');

	endif;

	else:
		set_msg('<p>Usuario Nao Existe</p>');

endif;
endif;
$dados['titulo'] = 'Login Sistema - Revotech';
$dados['h2'] = 'Login Painel';
$this->load->view('painel/login', $dados);

}

public function alterar(){
	verifica_login();

$this->form_validation->set_rules('login','Login', 'trim|required|min_length[5]');
$this->form_validation->set_rules('email','E-mail', 'trim|required|valid_email');
$this->form_validation->set_rules('senha','Senha', 'trim|min_length[6]');
if(isset($_POST['senha']) && $_POST['senha'] != ''):
	$this->form_validation->set_rules('senha2','Repita a Senha', 'trim|required|min_length[6]|matches[senha]');
endif;

if($this->form_validation->run() == FALSE):
	if(validation_errors()):
		set_msg(validation_errors());
	endif;
else:
$dados_form = $this->input->post();
	$this->option->update_option('user_login', $dados_form['login']);
	$this->option->update_option('user_email', $dados_form['email']);
 	
 	if(isset($dados_form['senha']) && $dados_form['senha'] != ''):
	$this->option->update_option('user_pass', password_hash( $dados_form['senha'], PASSWORD_DEFAULT));

endif;
set_msg('<p>Dados Alterados com Sucesso</p>');
endif;


$_POST['login'] = $this->option->get_option('user_login');
$_POST['email'] = $this->option->get_option('user_email');
$dados['titulo'] = 'Config Sistema - Revotech';
$dados['h2'] = 'Alterar Configuração Basica';
$this->load->view('painel/config', $dados);

}


public function logout(){


$this->session->unset_userdata('logged');
$this->session->unset_userdata('user_login');
$this->session->unset_userdata('user_email');
set_msg('<p> Você saiu do sistema !</p>');
redirect('setup/login', 'refresh');
}
}
	