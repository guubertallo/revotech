<?php $this->load->view('header'); ?>



     <!--Main section-->
      <section class="section main-section parallax-scene-js" style="background:url('<?php echo base_url('assets/images/bg-1-1700x803.jpg') ?>') no-repeat center center; background-size:cover;">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-xl-8 col-12">
              <div class="main-decorated-box text-center text-xl-left">
                <h1 class="text-white text-xl-center wow slideInRight" data-wow-delay=".3s"><span class="align-top offset-top-30 d-inline-block font-weight-light prefix-text"></span><span class="big font-weight-bold d-inline-flex offset-right-170">Soluções</span><span class="biggest d-block d-xl-flex font-weight-bold">Completas</span></h1>
                <div class="decorated-subtitle text-italic text-white wow slideInLeft">Para Automação Comercial.</div>
              </div>
            </div>
            <div class="col-12 text-center offset-top-75" data-wow-delay=".2s"><a class="button-way-point d-inline-block text-center d-inline-flex flex-column justify-content-center" href="#" data-custom-scroll-to="about"><span class="fa-chevron-down"></span></a></div>
          </div>
        </div>
        <div class="decorate-layer">
          <div class="layer-1">
            <div class="layer" data-depth=".20"><img src="<?php echo base_url('assets/images/parallax-item-1-563x532.png') ?>" alt="" width="563" height="266"/>
            </div>
          </div>
          <div class="layer-2">
            <div class="layer" data-depth=".30"><img src="<?php echo base_url('assets/images/parallax-item-2-276x343.png') ?>" alt="" width="276" height="171"/>
            </div>
          </div>
          <div class="layer-3">
            <div class="layer" data-depth=".40"><img src="<?php echo base_url('assets/images/parallax-item-3-153x144.png') ?>" alt="" width="153" height="72"/>
            </div>
          </div>
          <div class="layer-4">
            <div class="layer" data-depth=".20"><img src="<?php echo base_url('assets/images/parallax-item-4-69x74.png') ?>" alt="" width="69" height="37"/>
            </div>
          </div>
          <div class="layer-5">
            <div class="layer" data-depth=".40"><img src="<?php echo base_url('assets/images/parallax-item-5-72x75.png') ?>" alt="" width="72" height="37"/>
            </div>
          </div>
          <div class="layer-6">
            <div class="layer" data-depth=".30"><img src="<?php echo base_url('assets/images/parallax-item-6-45x54.png') ?>" alt="" width="45" height="27"/>
            </div>
          </div>
        </div>
      </section>
      <!--Counters-->
      <section class="section">
        <div class="container" style="padding: 30px;">
          <div class="row text-center justify-content-center">
            <div class="col-xl-3 ">
              <div class="counter-classic">
                <div class="counter-classic-number"><span class="icon-lg novi-icon offset-right-10 mercury-icon-time" style="color: #1d1d1d"></span><span class="counter" data-speed="2000" style="color: #e1c067">5</span>
                </div>
                <div class="counter-classic-title"style="color: #1d1d1d" >Anos de Experiência</div>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12">
              <div class="counter-classic">
                <div class="counter-classic-number"><span class="icon-lg novi-icon offset-right-10 mercury-icon-folder" style="color: #1d1d1d"></span><span class="counter" data-speed="2000" style="color: #e1c067">547</span>
                </div>
                <div class="counter-classic-title" style="color: #1d1d1d">Clientes atendidos</div>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 col-12">
              <div class="counter-classic">
                <div class="counter-classic-number"><span class="icon-lg novi-icon offset-right-10 mercury-icon-users" style="color: #1d1d1d"></span><span class="counter"  data-speed="2000" style="color: #e1c067">99</span><span class="symbol" style="color: #e1c067">%</span>
                </div>
                <div class="counter-classic-title" style="color: #1d1d1d">Satisfação</div>
              </div>
            </div>
            
          </div>
        </div>
      </section>
      <!--Pricing-->
      <section class="section bg-xs-overlay" >
        <div class="container">
          <div class="row row-50 justify-content-center">
            <div class="col-12 text-center col-md-10 col-lg-8">
              <div class="section-name wow fadeInRight" data-wow-delay=".2s">Sistemas</div>
              <h3 class="wow fadeInLeft text-capitalize" data-wow-delay=".3s">Ideal para Auxiliar<span class="text-primary"> sua empresa</span></h3>
              
            </div>
          </div>
          <div class="row row-30 justify-content-center">
            <div class="col-xl-4 col-md-6 col-12 wow fadeInDown" data-wow-delay=".3s">
              <div class="pricing-box bg-gray-dark">
                <div class="pricing-box-tittle"><b>XD POS</b></div>
                 <p>Ideal para os que querem controlar somente as vendas</p>
                <hr/>
               
                
             
                <p><b>● Multiplataforma</b><br>pode ser instalado em diversos tipos de aparelhos<br>
                   <b>● Busca Inteligente</b><br>encontre produtos apenas digitando partes da descrição<br>
                   <b>● Cadastro Automatico</b><br>cadastre produto utilizando nosso banco de dados online<br>
                   <b>E muito mais.</b><Br>Clique no botao abaixo para saber mais sobre o Navi Vendas</p>

                <a class="button button-190 button-circle btn-primary-rounded" href="#">SAIBA MAIS</a>
              </div>
            </div>


            <div class="col-xl-4 col-md-6 col-12 wow fadeInUp" data-wow-delay=".4s">
              <div class="pricing-box bg-gray-primary">
                <div class="pricing-box-tittle"><b>XD REST</b></div>
                <p>Ideal para os que querem um controle total da empresa</p>
                <hr/>
              <p><b>● Multiplataforma</b><br>pode ser instalado em diversos tipos de aparelhos<br>
                   <b>● Busca Inteligente</b><br>encontre produtos apenas digitando partes da descrição<br>
                   <b>● Cadastro Automatico</b><br>cadastre produto utilizando nosso banco de dados online<br>
                   <b>E muito mais.</b><Br>Clique no botao abaixo para saber mais sobre o Link Pro</p>

                <a class="button button-190 button-circle btn-rounded-outline" href="#">SAIBA MAIS</a>
              </div>
            </div>
            <div class="col-xl-4 col-md-6 col-12 wow fadeInDown" data-wow-delay=".3s">
              <div class="pricing-box bg-gray-dark">
                <div class="pricing-box-tittle"><b>XD SPA</b></div>
                <p>Ideal para os que querem automatizar o restaurante</p>
                <hr/>
               <p><b>● Multiplataforma</b><br>pode ser instalado em diversos tipos de aparelhos<br>
                   <b>● Busca Inteligente</b><br>encontre produtos apenas digitando partes da descrição<br>
                   <b>● Cadastro Automatico</b><br>cadastre produto utilizando nosso banco de dados online<br>
                   <b>E muito mais.</b><Br>Clique no botao abaixo para saber mais sobre o Sistema</p>
                   <a class="button button-190 button-circle btn-primary-rounded" href="#">SAIBA MAIS</a>
              </div>
            </div>
          </div>
        </div>
      </section>



      <section class="section bg-xs-overlay">
        <div class="container">
          <div class="row row-50 justify-content-center">
            <div class="col-12 text-center col-md-10 col-lg-8">
              
              
            </div>
          </div>
          <div class="row row-30 justify-content-center">
            <div class="col-xl-4 col-md-6 col-12 wow fadeInDown" data-wow-delay=".3s">
              <div class="pricing-box bg-gray-dark">
                <div class="pricing-box-tittle"><b>LINK PRO</b></div>
                 <p>Ideal para os que querem controlar somente as vendas</p>
                <hr/>
               
                
             
                <p><b>● Multiplataforma</b><br>pode ser instalado em diversos tipos de aparelhos<br>
                   <b>● Busca Inteligente</b><br>encontre produtos apenas digitando partes da descrição<br>
                   <b>● Cadastro Automatico</b><br>cadastre produto utilizando nosso banco de dados online<br>
                   <b>E muito mais.</b><Br>Clique no botao abaixo para saber mais sobre o Navi Vendas</p>

                <a class="button button-190 button-circle btn-primary-rounded" href="#">SAIBA MAIS</a>
              </div>
            </div>

            
            <div class="col-xl-4 col-md-6 col-12 wow fadeInUp" data-wow-delay=".4s">
              <div class="pricing-box bg-gray-dark">
                <div class="pricing-box-tittle"><b>Revo Vendas</b></div>
                <p>Ideal para os que querem um controle total da empresa</p>
                <hr/>
              <p><b>● Multiplataforma</b><br>pode ser instalado em diversos tipos de aparelhos<br>
                   <b>● Busca Inteligente</b><br>encontre produtos apenas digitando partes da descrição<br>
                   <b>● Cadastro Automatico</b><br>cadastre produto utilizando nosso banco de dados online<br>
                   <b>E muito mais.</b><Br>Clique no botao abaixo para saber mais sobre o Link Pro</p>

                <a class="button button-190 button-circle btn-primary-rounded" href="#">SAIBA MAIS</a>
              </div>
            </div>
            <div class="col-xl-4 col-md-6 col-12 wow fadeInDown" data-wow-delay=".3s">
              <div class="pricing-box bg-gray-dark">
                <div class="pricing-box-tittle"><b>Revo Ponto</b></div>
                <p>Ideal para os que querem automatizar o restaurante</p>
                <hr/>
               <p><b>● Multiplataforma</b><br>pode ser instalado em diversos tipos de aparelhos<br>
                   <b>● Busca Inteligente</b><br>encontre produtos apenas digitando partes da descrição<br>
                   <b>● Cadastro Automatico</b><br>cadastre produto utilizando nosso banco de dados online<br>
                   <b>E muito mais.</b><Br>Clique no botao abaixo para saber mais sobre o Sistema</p>
                   <a class="button button-190 button-circle btn-primary-rounded" href="#">SAIBA MAIS</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Owl Carousel 
      <section class="section section-md bg-gray-lighten">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-xl-10">
              <div class="section-name wow fadeInRight text-center" data-wow-delay=".2s">Depoimentos</div>
              <h3 class="wow fadeInLeft text-capitalize text-center" data-wow-delay=".3s">Vejam o que falam<span class="text-primary"> sobre nós</span></h3>
              <div class="owl-carousel review-carousel" data-items="1" data-sm-items="1" data-md-items="1" data-lg-items="1" data-xl-items="1" data-xxl-items="1" data-dots="true" data-nav="false" data-stage-padding="0" data-loop="false" data-margin="0" data-mouse-drag="true" data-autoplay="false">
                <div class="item">
                  <div class="item-preview wow fadeInDown" data-wow-delay=".2s"><img src="<?php echo base_url('assets/images/user-1-216x216.jpg') ?>" alt="" width="216" height="108"/>
                  </div>
                  <div class="item-description wow fadeInUp" data-wow-delay=".3s">
                    <p>I was impressed by the quality of what your specialists did. They quickly found out what was the main problem of my company and helped me form a correct strategy, which worked perfectly and set my business on the right path.</p>
                    <div class="item-subsection"><span class="item-subsection-title devider-left">Heather Perry</span><span>Regular Client</span></div>
                  </div>
                </div>
                <div class="item">
                  <div class="item-preview wow fadeInDown" data-wow-delay=".2s"><img src="<?php echo base_url('assets/images/user-1-216x216.jpg') ?>" alt="" width="216" height="108"/>
                  </div>
                  <div class="item-description wow fadeInUp" data-wow-delay=".3s">
                    <p>I appreciate what you’ve done to help my small company develop and thrive in that market niche that we specialize in. Your business consulting experts are the best in the whole industry and I’m going to recommend you to my partners!</p>
                    <div class="item-subsection"><span class="item-subsection-title devider-left">Donald Hughes</span><span>Regular Client</span></div>
                  </div>
                </div>
                <div class="item">
                  <div class="item-preview wow fadeInDown" data-wow-delay=".2s"><img src="<?php echo base_url('assets/images/user-1-216x216.jpg') ?>" alt="" width="216" height="108"/>
                  </div>
                  <div class="item-description wow fadeInUp" data-wow-delay=".3s">
                    <p>My cooperation with your team helped me understand that you really care about your clients – it was proved by a lot of positive reviews already – and that's why I chose you. Thank you for a great job, you are true professionals!</p>
                    <div class="item-subsection"><span class="item-subsection-title devider-left">Anthony Parker</span><span>Regular Client</span></div>
                  </div>
                </div>
                <div class="item">
                  <div class="item-preview wow fadeInDown" data-wow-delay=".2s"><img src="<?php echo base_url('assets/images/user-1-216x216.jpg') ?>" alt="" width="216" height="108"/>
                  </div>
                  <div class="item-description wow fadeInUp" data-wow-delay=".3s">
                    <p>Two years after СonsultBiz’s involvement, we are remarkably successful and the leader in served markets. This brought industry knowledge, best practices, and real-world solutions to the intricate challenges we faced.</p>
                    <div class="item-subsection"><span class="item-subsection-title devider-left">Jennifer Coleman</span><span>Regular Client</span></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section> -->




       <!--Brands-->

      <section class="section section-md bg-gray-lighten">
<center><div class="section-name wow fadeInRight" data-wow-delay=".2s">nossos clientes</div></center><br>
        <div class="container">

          <div class="row">

            <!-- Owl Carousel-->
            <div class="owl-carousel text-center owl-brand" data-items="1" data-sm-items="2" data-md-items="3" data-lg-items="3" data-xl-items="5" data-xxl-items="5" data-dots="true" data-nav="false" data-stage-padding="15" data-loop="false" data-margin="30" data-mouse-drag="false" data-autoplay="true">

              <div class="item"><img src="<?php echo base_url('assets/images/brand-1-200x48.png') ?>" alt="" width="200" height="24"/>
              </div>
             <div class="item"><img src="<?php echo base_url('assets/images/brand-1-200x48.png') ?>" alt="" width="200" height="24"/>
              </div>
              <div class="item"><img src="<?php echo base_url('assets/images/brand-1-200x48.png') ?>" alt="" width="200" height="24"/>
              </div>
              <div class="item"><img src="<?php echo base_url('assets/images/brand-1-200x48.png') ?>" alt="" width="200" height="24"/>
              </div>
              <div class="item"><img src="<?php echo base_url('assets/images/brand-1-200x48.png') ?>" alt="" width="200" height="24"/>
              </div>
            </div>
          </div>
        </div>
      </section>

 
<?php $this->load->view('footer'); ?>