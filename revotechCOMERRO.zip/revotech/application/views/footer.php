      <!--Footer-->
      <footer class="section footer-classic section-sm">
        <div class="container">
          <div class="row row-30">
            <div class="col-lg-3 wow fadeInLeft">
              <!--Brand--><a class="brand" href="index.html"><img class="brand-logo-dark" src="<?php echo base_url('assets/images/logo-default-200x34.png') ?>" alt="" width="100" height="17"/><img class="brand-logo-light" src="<?php echo base_url('assets/images/logo-default-200x34.png') ?>" alt="" width="100" height="17"/></a>
              <p class="footer-classic-description offset-top-0 offset-right-25">A Revotech fornece uma gama completa de soluções e serviços de informatica e assessoria de negócios para pequenas, médias e empresas internacionais em todo o mundo. </p>
            </div>
            <div class="col-lg-3 col-sm-8 wow fadeInUp">
              <P class="footer-classic-title">Contato</P>
              <div class="d-block offset-top-0">Rua Nove, 45 - Portal dos Ipes<span class="d-lg-block">Ribeirão Preto-SP</span></div><a class="d-inline-block accent-link" href="mailto:#">contato@revotechsolucoes.com.br</a><a class="d-inline-block" href="tel:#">+55 16 98163-9782</a>
              
            </div>
            <div class="col-lg-2 col-sm-4 wow fadeInUp" data-wow-delay=".3s">
              <P class="footer-classic-title">Links Rapidos</P>
              <ul class="footer-classic-nav-list">
                <li><a href="index.html">Home</a></li>
                <li><a href="about.html">Sobre Nós</a></li>
                <li><a href="#">Soluções</a></li>
                <li><a href="#">Equipamentos</a></li>
                <li><a href="#">Ajuda</a></li>
                <li><a href="contacts.html">Contato</a></li>
              </ul>
            </div>
            <div class="col-lg-4 wow fadeInLeft" data-wow-delay=".2s">
              <P class="footer-classic-title">Receba Informações e Notícias</P>
              <form class="rd-mailform text-left footer-classic-subscribe-form" data-form-output="form-output-global" data-form-type="contact" method="post" action="bat/rd-mailform.php">
                <div class="form-wrap">
                  <label class="form-label" for="subscribe-email">Digite seu e-mail</label>
                  <input class="form-input" id="subscribe-email" type="email" name="email" data-constraints="@Email @Required">
                </div>
                <div class="form-button group-sm text-center text-lg-left">
                  <button class="button button-primary button-circle" type="submit">Inscreva-se</button>
                </div>
              </form>
              <p>Seja o primeiro a saber das nossas últimas notícias, atualizações e ofertas especiais.</p>
            </div>
          </div>
        </div>
        <div class="container wow fadeInUp" data-wow-delay=".4s">
          <div class="footer-classic-aside">
            <p class="rights"><span>&copy;&nbsp;</span><span class="copyright-year"></span>. Todos os Direitos Reservados</p>
            <ul class="social-links">
              
              <li><a class="fa fa fa-whatsapp" href="#"></a></li>
              <li><a class="fa fa-facebook" href="#"></a></li>
              <li><a class="fa fa-instagram" href="#"></a></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
    <div class="snackbars" id="form-output-global"></div>
   
    
  </body>
</html>