<!DOCTYPE html>

<html lang="pt-br">
<head>
<meta charset="utf-8"/>
<meta name="robots" content="index, follow">
<meta name="revisit-after" content="1 day">
<meta name="author" content="Gustavo Bertallo">
<meta name="language" content="Portuguese">


<link rel="stylesheet" href="<?php echo base_url('assets/css/stylesmenu.css') ?>" rel="stylesheet">
<link rel="icon" href="<?php echo base_url('assets/images/favicon.ico') ?>" type="image/x-icon">

   <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
   <script src="<?php echo base_url('assets/js/cycle.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/jquery.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/script.js') ?>"></script>
   <script src="<?php echo base_url('assets/js/jquery.cycle.lite.js') ?>"></script>
     <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Montserrat:300,400,700%7CPoppins:300,400,500,700,900">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/util.css') ?>">
<title><?php echo $titulo; ?></title>
</head>
<style>
body{
   background-color: #1d1d1d;
}
</style>


<body>

<header>
<div style="background-color: #e1c067; position: relative;" a> 
<center>
  <nav class="nav">
   <ul>
      <li><a href="#">Ver Site</a></li>
      <li><a href="#">Blog</a></li>
      <li><a href="#">Produtos</a></li>
      <li><a href="#">Treinamentos</a></li>
      <li><a href="#">Downloads</a></li>
      <li><a href="#">Configs</a></li>
      <li><a href="#">Logout</a></li>
     
      
   </ul>
</nav>
  </center>
</div>
</header>

