<!DOCTYPE html>
<html class="wide wow-animation" lang="pt-br">
  <head>
    <title><?php echo $titulo; ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="<?php echo base_url('assets/images/favicon.ico') ?>" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Montserrat:300,400,700%7CPoppins:300,400,500,700,900">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/fonts.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css') ?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/util.css') ?>">



    <style>.ie-panel{display: none;background: #000000;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>

<div class="limiter">
		<div class="container-login100">

			<div class="wrap-login100">

				<div class="login100-pic js-tilt" data-tilt>
					<img src="<?php echo base_url('assets/images/img-01.png') ?>" alt="IMG">
					<br><br>

<center>
					<?php
	if($msg = get_msg()):
		echo '<div class="msg-box">'.$msg.'</div>';
	endif;
?>
</center>

				</div>





				<form action="https://revotechsolucoes.com.br/index.php/setup/login" method="post" class="login100-form validate-form">
					<span class="login100-form-title">
						<?php echo $h2; ?>
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Usuario requerido">
						<input class="input100" type="text" name="login" placeholder="Login">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
						<span class="fa-user-md" aria-hidden="true"></span>
						</span>
					</div>

					
					<div class="wrap-input100 validate-input" data-validate = "Password requerida">
						<input class="input100" type="password" name="senha" placeholder="Senha">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<span class="fa fa-lock" aria-hidden="true"></span>
						</span>
					</div>

				
					
					<div class="container-login100-form-btn">
						<button  name="enviar" class="login100-form-btn">
							Efetuar Login
						</button>
					</div>

					<br><br>
					<br><br>
					
				</form>
			</div>
		</div>
	</div>
	




  </body>

  <script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
	<script src="<?php echo base_url('assets/js/main.js') ?>"></script>
  </html>