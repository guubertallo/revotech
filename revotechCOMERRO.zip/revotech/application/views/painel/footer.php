     <Center> 
      <footer>


         <script type="text/javascript">
   $('.drop')
  .mouseover(function() {
  $('.dropdown2').show(200).fadeIn();
});
$('.drop')
  .mouseleave(function() {
  $('.dropdown2').hide(200).fadeOut(200);     
});


</script>
      
                   <p class="rights"><span>&copy;&nbsp;</span><span class="copyright-year"><?php echo date('Y'); ?> </span>. Todos os Direitos Reservados</p>
            
          
      </footer>
 
   </Center>
  
  </body>
  </html>